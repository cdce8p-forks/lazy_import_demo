"""A module that lazy imports a broken dependency and uses it in a function."""
print("✅ lazy_demo.broken loaded successfully!")

# Lazy import a module that will fail when loaded
lazy from lazy_demo.broken_dep import foo

def bar():
    """Call this function to trigger the lazy import, which will raise ZeroDivisionError."""
    print(foo)

# Uncomment to trigger immediately on import:
# bar()
