"""Demo package to showcase lazy imports behavior."""
print("📦 lazy_demo package loaded!")
