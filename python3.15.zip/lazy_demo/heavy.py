"""A 'heavy' submodule to demonstrate deferred loading."""
print("⚙️  lazy_demo.heavy loaded! (this is a 'heavy' module)")

def compute():
    """Simulate expensive computation."""
    return "Heavy computation result"
